//
//  TableViewCell.m
//  3DTOUCH DEMO
//
//  Created by 胡剑 on 16/8/31.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

#import "TableViewCell.h"
#import "UIViewExt.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        self.imageview=[[UIImageView alloc]initWithFrame:CGRectMake(10,10, 50, 50)];
        self.imageview.image=[UIImage imageNamed:@"Icon.png"];
        [self.contentView addSubview:self.imageview];
        
        self.button1 = [[UIButton alloc]initWithFrame:CGRectMake(self.imageview.right+100,20,60,30)];
        self.button1.backgroundColor=[UIColor clearColor];
        self.button1.titleLabel.font=[UIFont systemFontOfSize:16];
        [self.button1 setTitle:@"评论" forState:UIControlStateNormal];
        [self.button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.button1.tag=100;
        self.button1.layer.borderColor=[UIColor blackColor].CGColor;
        self.button1.layer.borderWidth=1;
        [self.contentView addSubview:self.button1];
        
        self.button2 = [[UIButton alloc]initWithFrame:CGRectMake(self.button1.right+20,20,60, 30)];
        self.button2.backgroundColor=[UIColor clearColor];
        self.button2.tag=101;
        [self.button2 setTitle:@"赞" forState:UIControlStateNormal];
        [self.button2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.button2.titleLabel.font=[UIFont systemFontOfSize:16];
        self.button2.layer.borderColor=[UIColor blackColor].CGColor;
        self.button2.layer.borderWidth=1;
        [self.contentView addSubview:self.button2];
    }
    
    return self;
}


@end
















