//
//  AppDelegate.m
//  3DTOUCH DEMO
//
//  Created by 胡剑 on 16/8/31.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self set3DTouch];
    
    self.window=[[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    self.window.backgroundColor=[UIColor whiteColor];
    self.window.rootViewController=[[UINavigationController alloc]initWithRootViewController:[ViewController new]];
    [self.window makeKeyAndVisible];

    return YES;

}

-(void)set3DTouch
{
    //每次进入app，count+1
    
    //这里是为了演示动态加载 3D TOUCH，使用NSUserDefaults存储数据。
    
    NSString * photocount = @"";
    
    if(![[NSUserDefaults standardUserDefaults]objectForKey:@"SharePhoto"])
    {
        [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"SharePhoto"];
        [[NSUserDefaults standardUserDefaults]synchronize];
         count=0;
        photocount  = @"分享照片";
    }
    else
    {
        NSString * s =(NSString*)[[NSUserDefaults standardUserDefaults]objectForKey:@"SharePhoto"];
        count=[s integerValue]+1;
        
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%ld",count] forKey:@"SharePhoto"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        photocount  = [NSString stringWithFormat:@"分享照片+%ld",(long)count];
    }
    
    
    
    UIApplicationShortcutIcon *icon1 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeCompose];
    UIApplicationShortcutIcon *icon2 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeSearch];
    UIApplicationShortcutIcon *icon3 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeCapturePhoto];
    
    UIMutableApplicationShortcutItem *item1 = [[UIMutableApplicationShortcutItem alloc]initWithType:@"0" localizedTitle:@"创建活动" localizedSubtitle:nil icon:icon1 userInfo:nil];
    UIMutableApplicationShortcutItem *item2 = [[UIMutableApplicationShortcutItem alloc]initWithType:@"1" localizedTitle:@"查找店铺" localizedSubtitle:nil icon:icon2 userInfo:nil];
    UIMutableApplicationShortcutItem *item3 = [[UIMutableApplicationShortcutItem alloc]initWithType:@"2" localizedTitle:photocount localizedSubtitle:nil icon:icon3 userInfo:nil];
    NSArray *items = @[item1, item2, item3];
    [UIApplication sharedApplication].shortcutItems = items;
}

- (void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler
{
        NSString * type = shortcutItem.type;
        NSLog(@"type=%@",type);
    
    //在这里处理页面跳转   type 1、2、3就是3D touch的3个按钮。
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
