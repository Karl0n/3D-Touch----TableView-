//
//  AppDelegate.h
//  3DTOUCH DEMO
//
//  Created by 胡剑 on 16/8/31.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSInteger count;
}
@property (strong, nonatomic) UIWindow *window;


@end

