//
//  ViewController.m
//  3DTOUCH DEMO
//
//  Created by 胡剑 on 16/8/31.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

#import "ViewController.h"
#import "DetailViewController.h"
#import "TableViewCell.h"

#define ScreenWidth self.view.frame.size.width
#define ScreenHeight self.view.frame.size.height

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UIViewControllerPreviewingDelegate>
{
    UIButton * btn1;
    UIButton * btn2;

}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.tableFooterView=[UIView new];
    [self registerForPreviewingWithDelegate:self sourceView:self.tableView];  //注册代理
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 20;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(!cell)
    {
        cell=[[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }

    return cell;
}


- (UIViewController *)previewingContext:(id <UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location
{
    
    
    NSIndexPath * IndexPath = [self.tableView indexPathForRowAtPoint:location];
    TableViewCell * cell = [self.tableView cellForRowAtIndexPath:IndexPath];  //获取touch的那个cell
    
    NSInteger index=3;
    
    NSMutableArray * array =[NSMutableArray array];
    [array addObject:cell.imageview];
    [array addObject:cell.button1];
    [array addObject:cell.button2];
    
    for(UIView * view in array)
    {
        
        if([self touchedView:view and:location])
        {
            
            if([view isKindOfClass:[UIButton class]]) //判断touch是不是在button上
            {
                UIButton*btn = (UIButton*)view;
                
                index=[array indexOfObject:btn]; // index为1或者2
            }
            else if([view isKindOfClass:[UIImageView class]])  //判断touch是不是在imageview上
            {
                index=0;
            }
        }
        
    }
    
    /*
       只有 设置了 previewingContext.sourceRect，你touch的那个控件才会突出显示，其他区域变模糊。
     */

    
    DetailViewController * vc=[[DetailViewController alloc]init];
    if(index==3)  //touch在button1 button2 imageview 之外的区域  即cell上
    {
        vc.string=[NSString stringWithFormat:@"3D Touched 第%ld行",IndexPath.row];
        previewingContext.sourceRect =  cell.frame;
    }
    else if(index==0)  //touch 头像
    {
        vc.string=[NSString stringWithFormat:@"3D Touched 第%ld行的头像",IndexPath.row];
        previewingContext.sourceRect = [self.view convertRect:cell.imageview.frame fromView:cell];
        
    }
    else if(index==1)  //touch 评论
    {
       vc.string=[NSString stringWithFormat:@"3D Touched 第%ld行的评论",IndexPath.row];
        previewingContext.sourceRect =  [self.view convertRect:cell.button1.frame fromView:cell];
    }
    else if(index==2)   //touch 赞
    {
       vc.string=[NSString stringWithFormat:@"3D Touched 第%ld行的赞",IndexPath.row];
        previewingContext.sourceRect =  [self.view convertRect:cell.button2.frame fromView:cell];
    }
    
    return vc;
}

-(void)previewingContext:(id<UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit
{
    [self showViewController:viewControllerToCommit sender:nil];
}

-(BOOL)touchedView:(UIView*)view and:(CGPoint)location
{
    CGPoint point = [view convertPoint:location fromView:self.tableView];
    
    return CGRectContainsPoint(view.bounds,point);
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
