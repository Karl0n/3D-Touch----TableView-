//
//  TableViewCell.h
//  3DTOUCH DEMO
//
//  Created by 胡剑 on 16/8/31.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell


@property(nonatomic,strong)UIImageView * imageview;  //头像
@property(nonatomic,strong)UIButton * button1;   //评论
@property(nonatomic,strong)UIButton * button2;  //赞



@end
